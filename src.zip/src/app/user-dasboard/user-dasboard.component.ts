import { Component } from '@angular/core';

@Component({
  selector: 'app-user-dasboard',
  templateUrl: './user-dasboard.component.html',
  styleUrl: './user-dasboard.component.css'
})
export class UserDasboardComponent {

}
