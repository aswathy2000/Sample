import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-aadhar',
  templateUrl: './aadhar.component.html',
  styleUrl: './aadhar.component.css'
})
export class AadharComponent {

  constructor(
    
    private router: Router
    
  ) {}

  loginAdmin(): void {
    this.router.navigate(['AadharApp/admin/logIn']);
  }

  loginUser(): void {
    this.router.navigate(['AadharApp/citizens/logIn']);
  }

}
